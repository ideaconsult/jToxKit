/** jToxKit - chem-informatics multi-tool-kit.
 * Base for widgets and UI-related stuff
 *
 * Author: Ivan (Jonan) Georgiev
 * Copyright © 2016-2020, IDEAConsult Ltd. All rights reserved.
 */

(function (jT, a$, $) {
    // Define more tools here
    jT.ui = $.extend(jT.ui, {
        templates: {},

        bakeTemplate: function (html, info, formatters) {
            var all$ = $(html);

            $('*', all$).each(function (i, el) {
                var liveData = null;

                // first, deal with the value field
                if (el.value && el.value.match(jT.templateRegExp)) {
                    liveData = { 'value': el.value };
                    el.value = jT.formatString(el.value, info, formatters);
                }

                // then, jump to deal with the attributes
                var allAttrs = el.attributes;
                for (var i = 0;i < allAttrs.length; ++i) {
                    if (allAttrs[i].specified && allAttrs[i].value.match(jT.templateRegExp)) {
                        if (liveData == null)
                            liveData = {};
                        liveData[allAttrs[i].name] = allAttrs[i].value;
                        allAttrs[i].value = jT.formatString(allAttrs[i].value, info, formatters);
                    }
                }

                // finally, go to text subnodes
                if (el.childNodes.length == 1 && el.childNodes[0].nodeType === Node.TEXT_NODE) {
                    var subEl = el.childNodes[0];

                    if (subEl.textContent.match(jT.templateRegExp)) {
                        if (liveData == null)
                            liveData = {};
                        liveData[''] = subEl.textContent;
                        subEl.textContent = jT.formatString(subEl.textContent, info, formatters);
                    }                    
                }

                if (liveData != null)
                    $(el).addClass('jtox-live-data').data('jtox-live-data', liveData);
            });

            return all$;
        },

        putTemplate: function (id, info, root) {
            var html = jT.ui.bakeTemplate(jT.ui.templates[id], info);
            return !root ? html : $(html).appendTo(root);
        },

        updateTree: function (root, info, formatters) {
            $('.jtox-live-data', root).each(function (i, el) {
                $.each($(el).data('jtox-live-data'), function (k, v) {
                    v = jT.formatString(v, info, formatters)
                    if (k === '')
                        el.innerHTML = v;
                    else if (k === 'value')
                        el.value = v;
                    else
                        el.attributes[k] = v;
                });
            });
        },

        fillHtml: function (id, info, formatters) {
            return jT.formatString(jT.ui.templates[id], info, formatters);
        },

        getTemplate: function (id, info, formatters) {
            return $(jT.ui.fillHtml(id, info, formatters));
        },

        updateCounter: function (str, count, total) {
            var re = null;
            var add = '';
            if (count == null)
                count = 0;
            if (total == null) {
                re = /\(([\d\?]+)\)$/;
                add = '' + count;
            } else {
                re = /\(([\d\?]+\/[\d\?\+-]+)\)$/;
                add = '' + count + '/' + total;
            }

            // now the addition
            if (!str.match(re))
                str += ' (' + add + ')';
            else
                str = str.replace(re, "(" + add + ")");

            return str;
        },

        enterBlur: function (e) {
            if (e.keyCode == 13)
                this.blur();
        },

        installHandlers: function (kit, root, defHandlers) {
            if (!root)
                root = kit.rootElement;
            if (!defHandlers)
                defHandlers = kit;
    
            $('.jtox-handler', root).each(function () {
                var thi$ = $(this),
                    name = thi$.data('handler'),
                    handler = _.get(kit.settings, [ 'handlers', name ], null) || defHandlers[name] || window[name];
    
                if (!handler) {
                    console.warn("jToxQuery: referring unknown handler: '" + name + "'");
                    return;
                }

                // Build the proper handler, taking into account if we want debouncing...
                var eventHnd = _.bind(handler, kit),
                    eventDelay = thi$.data('handlerDelay'),
                    eventName = thi$.data('handlerEvent');
                if (eventDelay != null)
                    eventHnd = _.debounce(eventHnd, parseInt(eventDelay));
                
                // Now, attach the handler, in the proper way
                if (eventName != null)
                    thi$.on(eventName, eventHnd);
                else if (this.tagName == "INPUT" || this.tagName == "SELECT" || this.tagName == "TEXTAREA")
                    thi$.on('change', eventHnd).on('keydown', jT.ui.enterBlur);
                else // all the rest respond on click
                    thi$.on('click', eventHnd);
            });
        },

        shortenedData: function (content, message, data) {
            var res = '';

            if (data == null)
                data = content;
            if (data.toString().length <= 5) {
                res += content;
            } else {
                res += '<div class="shortened"><span>' + content + '</div><i class="icon fa fa-copy fa-action"';
                if (message != null)
                    res +=  ' title="' + message + '"';
                res += ' data-uuid="' + data + '"></i>';
            }
            return res;
        },

        linkedData: function (content, message, data) {
            var res = '';

            if (data == null)
                data = content;
            if (data.toString().length <= 5)
                res += content;
            else {
                if (message != null) {
                    res += res += '<div title="' + message + '">' + content + '</div>';
                } else res += '<div >' + content + '</div>';
            }
            return res;
        },

        addTab: function (root, name, id, content) {
            // first try to see if there is same already...
            if (document.getElementById(id) != null) {
                console.warn('jToxKit: Trying to add a tab [' + name + '] with existing id:'  + id);
                return;
            }

            // first, create and add li/a element
            var a$ = $('<a>', { href: '#' + id }).html(name);
            $('ul', root[0]).append($('<li>').append(a$));

            // then proceed with the panel, itself...
            if (typeof content === 'function')
                content = $(content(root[0]));
            else if (typeof content === 'string')
                content = $(content);

            content.attr('id', id);
            root.append(content).tabs('refresh');
            return { tab: a$, content: content };
        },

        renderRange: function (data, unit, type, prefix) {
            var out = "";
            if (typeof data == 'string' || typeof data == 'number') {
                out += (type != 'display') ? data : ((!!prefix ? prefix + "&nbsp;=&nbsp;" : '') + jT.valueAndUnits(data, unit));
            } else if (typeof data == 'object' && data != null) {
                var loValue = _.trim(data.loValue),
                    upValue = _.trim(data.upValue);

                if (String(loValue) != '' && String(upValue) != '' && !!data.upQualifier && data.loQualifier != '=') {
                    if (!!prefix) {
                        out += prefix + "&nbsp;=&nbsp;";
                    }
                    out += (data.loQualifier == ">=") ? "[" : "(";
                    out += loValue + ", " + upValue;
                    out += (data.upQualifier == "<=") ? "]" : ") ";
                } else { // either of them is non-undefined

                    var fnFormat = function (p, q, v) {
                        var o = '';
                        if (!!p) {
                            o += p + ' ';
                        }
                        if (!!q) {
                            o += (!!p || q != '=') ? (q + ' ') : '';
                        }
                        return o + v;
                    };

                    if (String(loValue) != '') {
                        out += fnFormat(prefix, data.loQualifier || '=', loValue);
                    } else if (String(upValue) != '') {
                        out += fnFormat(prefix, data.upQualifier || '=', upValue);
                    } else {
                        if (!!prefix) {
                            out += prefix;
                        } else {
                            out += type == 'display' ? '-' : '';
                        }
                    }
                }

                out = out.replace(/ /g, "&nbsp;");
                if (type == 'display') {
                    unit = _.trim(data.unit || unit);
                    if (!!unit) {
                        out += '&nbsp;<span class="units">' + unit.replace(/ /g, "&nbsp;") + '</span>';
                    }
                }
            } else {
                out += '-';
            }
            return out;
        },

        putStars: function (kit, stars, title) {
            if (!kit.settings.shortStars) {
                var res = '<div title="' + title + '">';
                for (var i = 0;i < kit.settings.maxStars;++i) {
                    res += '<span class="fa fa-star fa-action jtox-inline';
                    if (i >= stars)
                        res += ' transparent';
                    res += '"></span>';
                }
                
                return res + '</div>';
            }
            else { // i.e. short version
                return '<span class="fa fa-action fa-star jtox-inline" title="' + title + '"></span>' + stars;
            }
        },

        renderRelation: function (data, type, full) {
            if (type != 'display')
                return _.map(data, 'relation').join(',');

            var res = '';
            for (var i = 0, il = data.length; i < il; ++i)
                res += '<span>' + data[i].relation.substring(4).toLowerCase() + '</span>' + 
                    jT.ui.fillHtml('info-ball', { href: full.URI + '/composition', title: data[i].compositionName + '(' + data[i].compositionUUID + ')' });
            return res;
        },

        rebindRenderers: function (kit, features, inplace) {
            var newFeats = {};

            for (var fId in features) {
                var fDef = features[fId];
                if (typeof fDef.render !== 'function')
                    continue;
                else if (inplace)
                    fDef.render = _.bind(fDef.render, kit);
                else
                    newFeats[fId] = _.defaults({ render: _.bind(fDef.render, kit) }, fDef);
            }

            return inplace ? features : _.defaults(newFeats, features);
        },

        attachEditors: function (kit, root, data, opts) {
            var allTags = [].concat(kit.settings.loTags, kit.settings.hiTags, kit.settings.units);
                field = null;
        
            // Make it easier to call with less checks.
            opts = opts || {};
        
            $('.ajax-auto', root).autocomplete({
                appendTo: root,
                source: function (request, response) {
                    var field = $(this.element).data('id');
                    _.set(opts.ajax, opts.searchPath, request.term);
        
                    jT.ambit.call(kit, $(this.element).data('service'), opts.ajax, function (data) {
                        response(!data ? [] : $.map(data.facet, function (item) {
                            var val = item[field] || '';
                            return {
                                label: val + (!item.count ? '' : " [" + item.count + "]"),
                                value: val
                            }
                        }));
                    });	
                },
                change: function (e, ui) {
                    var id = $(this).data('id'),
                        path = $(this).data('path') || _.find(kit.settings.editors, { id: id }).path,
                        value = !ui.item ? _.trim(this.value) : ui.item.value;
                    if (!opts.onChange || opts.onChange.call(kit, e, id,  path, value) !== false)
                        _.set(data, path, value);
                },
                minLength: kit.settings.minLength || 0
            });
        
            $('.tags-auto', root).autocomplete({
                appendTo: root,
                change: function (e, ui) {
                    var id = $(this).data('id'),
                        path = $(this).data('path') || _.find(kit.settings.editors, { id: id }).path,
                        value = parseValue(this.value);
                    if (!opts.onChange || opts.onChange.call(kit, e, id,  path, value) !== false)
                        _.set(data, path, value);
                },
                source: function (request, response) {
                    // extract the last term
                    var result = $.ui.autocomplete.filter(allTags, extractLast(request.term));
                    if (request.term == '') {
                        // if term is empty don't show results
                        // avoids IE opening all results after initialization.
                        result = '';
                    }
                    // delegate back to autocomplete
                    response(result);
                },
                focus: function () { // prevent value inserted on focus
                    return false;
                },
                select: function (event, ui) {
                    var theVal = this.value,
                        last = extractLast(theVal);
        
                    this.value = theVal.substr(0, theVal.length - last.length) + ui.item.value + ' ';
                    return false;
                }
            })
            .bind('keydown', function (event) {
                if (event.keyCode === $.ui.keyCode.TAB && !!autoEl.menu.active)
                    event.preventDefault();
            });
        
            // now initialize other fields, marked with '.no-auto''
            $('.no-auto', root).on('change', function (e) {
                var id = $(this).data('id'),
                    path = $(this).data('path') || _.find(kit.settings.editors, { id: id }).path,
                    value = $(this).val();
                if (!opts.onChange || opts.onChange.call(kit, e, id,  path, value) !== false)
                    _.set(data, path, value);
            });
        }
    });

// Now import all the actual skills ...
// ATTENTION: Kepp them in the beginning of the line - this is how smash expects them.

/** jToxKit - chem-informatics multi-tool-kit.
  * Base for widgets and UI-related stuff
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2017, IDEAConsult Ltd. All rights reserved.
  */

jT.ui = a$.extend(jT.ui, {
  querySettings: {}, // These can be modified from the URL string itself.
	templateRoot: null,
	callId: 0,

  // initializes one kit, based on the kit name passed, either as params, or found within data-XXX parameters of the element
  initKit: function(element, opts) {
    var self = this,
        dataParams = element.data(),
        kit = dataParams.kit,
        topSettings = { baseUrl: jT.formBaseUrl(document.location.href) };

    // first - skip, if we're manual...
    if (!!dataParams.manualInit)
      return null;

  	// we need to traverse up, to collect some parent's settings...
  	a$.each(element.parents('.jtox-kit,.jtox-widget').toArray().reverse(), function(el) {
  	  parent = self.kit(el);
    	if (parent != null)
      	topSettings = $.extend(topSettings, parent.settings, { baseUrl: parent.baseUrl });
  	});

    // This should be priority from low to high: inherited -> data-* provided -> programmatically provided -> query string provided
    dataParams = $.extend(_.cloneDeep(topSettings), dataParams, opts, self.querySettings);
    dataParams.baseUrl = jT.fixBaseUrl(dataParams.baseUrl);
    dataParams.target = element;
    
    if (dataParams.id === undefined)
      dataParams.id = element.attr('id');

	  // the real initialization function
    var realInit = function (params) {
    	if (!kit)
        return null;
        
      // add jTox if it is missing AND there is not existing object/function with passed name. We can initialize ketcher and others like this too.
    	var fn = window[kit];
    	if (typeof fn !== 'function') {
  	  	kit = kit.charAt(0).toUpperCase() + kit.slice(1);
  	  	fn = jT.ui[kit] || jT[kit];
  	  }

    	var obj = null;
      if (typeof fn == 'function')
    	  obj = new fn(params);
      else if (typeof fn == "object" && typeof fn.init == "function")
        obj = fn.init(params);

      if (obj != null) {
        if (fn.prototype.__kits === undefined)
          fn.prototype.__kits = [];
        fn.prototype.__kits.push(obj);
      }
      else
        console.log("jToxError: trying to initialize unexistent jTox kit: " + kit);

      return obj;
    };

	  // first, get the configuration, if such is passed
	  if (dataParams.configFile != null) {
	    // we'll use a trick here so the baseUrl parameters set so far to take account... thus passing 'fake' kit instance
	    // as the first parameter of jT.ambit.call();
  	  $.ajax({ settings: "GET", url: dataParams.configFile }, function(config){
    	  if (!!config)
    	    $.extend(true, dataParams, config);
        element.data('jtKit', realInit(dataParams));
  	  });
	  }
	  else {
      var config = dataParams.configuration;
      if (typeof config === 'string')
        config = window[config];
      if (typeof config === 'function')
        config = config.call(kit, dataParams, kit);
      if (typeof config === 'object')
        $.extend(true, dataParams, config);

      delete dataParams.configuration;

      var kitObj = realInit(dataParams);
      element.data('jtKit', kitObj);
      return kitObj;
	  }
  },

  // the jToxKit initialization routine, which scans all elements, marked as 'jtox-kit' and initializes them
	initialize: function(root) {
  	var self = this;

  	if (!root) {
      // make this handler for UUID copying. Once here - it's live, so it works for all tables in the future
      $(document).on('click', '.jtox-kit div.shortened + .icon', function () { jT.copyToClipboard($(this).data('uuid')); return false;});
      // install the click handler for fold / unfold
      $(document).on('click', '.jtox-foldable>.title', function(e) { $(this).parent().toggleClass('folded'); });
      // install diagram zooming handlers
      $(document).on('click', '.jtox-diagram .icon', function () {
        $(this).toggleClass('fa-search-plus fa-search-minus');
        $('img', this.parentNode).toggleClass('jtox-smalldiagram');
      });

      // scan the query parameter for settings
      var url = jT.parseURL(document.location);
      
      self.querySettings = url.params;
      if (!!self.querySettings.baseUrl)
        self.querySettings.baseUrl = jT.fixBaseUrl(self.querySettings.baseUrl);

      self.fullUrl = url;
      root = document;
  	}

  	// now scan all insertion divs
  	var fnInit = function() { self.initKit($(this)); };
  	$('.jtox-kit', root).each(fnInit);
  	$('.jtox-widget', root).each(fnInit);
	},

	kit: function (element) {
    return $(element).closest('.jtox-kit,.jtox-widget').data('jtKit');
	},
	
	attachKit: function (element, kit) {
  	return $(element).data('jtKit', kit);
	}

});
/** jToxKit - chem-informatics multi-tool-kit.
  * A generic widget for list management
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2016, IDEAConsult Ltd. All rights reserved.
  */

jT.ListWidget = function (settings) {
  a$.extend(true, this, a$.common(settings, this));
	this.target = $(settings.target);
	this.length = 0;
	
	this.clearItems();
};

jT.ListWidget.prototype = {
  itemId: "id",
  
  populate: function (docs, callback) {
  	this.items = docs;
  	this.length = docs.length;
  	
  	this.target.empty();
  	for (var i = 0, l = docs.length; i < l; i++)
      this.target.append(this.renderItem(typeof callback === "function" ? callback(docs[i]) : docs[i]));
  },
  
  addItem: function (doc) {
  	this.items.push(doc);
  	++this.length;
  	return this.renderItem(doc);
  },
  
  clearItems: function () {
  	this.target.empty();
  	this.items = [];
  	this.length = 0;
  },
  
  findItem: function (id) {
  	var self = this;
  	return a$.findIndex(this.items, typeof id !== "string" ? id : function (doc) { return doc[self.itemId] === id; });
  },
  
  eraseItem: function (id) {
  	var i = this.findItem(id),
  	    r = (i >= 0) ? this.items.splice(i, 1)[0] : false;

    this.length = this.items.length;
    return r;
  },
  
  enumerateItems: function (callback) {
  	var els = this.target.children();
  	for (var i = 0, l = this.items.length; i < l; ++i)
  		callback.call(els[i], this.items[i]);
  }
}
/** jToxKit - chem-informatics multi-tool-kit.
  * A generic widget for box of tag management.
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2016, IDEAConsult Ltd. All rights reserved.
  */

jT.TagWidget = function (settings) {
  a$.extend(true, this, a$.common(settings, this));

  this.target = $(settings.target);
  if (!!this.subtarget)
    this.target = this.target.find(this.subtarget).eq(0);
    
  this.id = settings.id;  
  this.color = this.color || this.target.data("color");
  if (!!this.color)
    this.target.addClass(this.color);
};

jT.TagWidget.prototype = {
  __expects: [ "hasValue", "clickHandler" ],
  color: null,
  renderItem: null,
  onUpdated: null,
  subtarget: null,
  
  init: function (manager) {
    a$.pass(this, jT.TagWidget, "init", manager);
    this.manager = manager;
  },
  
  populate: function (objectedItems, preserve) {
    var self = this,
    		item = null, 
    		total = 0,
    		el, selected, value;
    
    if (objectedItems.length == null || objectedItems.length == 0) {
      if (!preserve)
        this.target.html("No items found in this selection").addClass("jt-no-tags");
    }
    else {
      this.target.removeClass("jt-no-tags");
      objectedItems.sort(function (a, b) {
        return (a.value || a.val) < (b.value || b.val) ? -1 : 1;
      });
      
      if (!preserve)
        this.target.empty();
        
      for (var i = 0, l = objectedItems.length; i < l; i++) {
        item = objectedItems[i];
        value = item.value || item.val;
        selected = this.exclusion && this.hasValue(value);
        total += item.count;
        
        item.title = value.toString();
        if (typeof this.modifyTag === 'function')
          item = this.modifyTag(item);

        if (!selected)
          item.onMain = self.clickHandler(value);
        
        this.target.append(el = this.renderItem(item));
        
        if (selected)
          el.addClass("selected");
      }
    }
      
    a$.act(this, this.onUpdated, total);
  }
};
/** jToxKit - chem-informatics multi-tool-kit.
  * A generic widget for autocomplete box management.
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2016, IDEAConsult Ltd. All rights reserved.
  *
  */

jT.AutocompleteWidget = function (settings) {
  a$.extend(true, this, a$.common(settings, this));
  this.target = $(settings.target);
  this.lookupMap = settings.lookupMap || {};
};

jT.AutocompleteWidget.prototype = {
  __expects: [ "doRequest", "onSelect" ],
  tokenMode: true,

  init: function (manager) {
    var self = this;
        
    // now configure the "accept value" behavior
    this.findBox = this.target.find('input').addBack('input').on("change", function (e) {
      if (self.requestSent)
        return;
      
      var thi$ = $(this);
      if (!self.onSelect(thi$.val()))
        return;
        
      thi$.blur()[self.tokenMode ? 'tokenfield' : 'autocomplete']("disable");
    });

    // configure the auto-complete box. 
    var boxOpts = {
      'minLength': 0,
      'source': function (request, callback) {
        self.reportCallback = callback;
        self.doRequest(request.term);
      },
      'select': function(event, ui) {
        self.requestSent = false;
        if (!ui.item)
          return;
        if (self.onSelect)
          self.requestSent = self.onSelect(ui.item);
        if (self.onAdded)
          self.requestSent = self.requestSent || self.onAdded(ui.item);
      }
    };

    if (!this.tokenMode)
      this.findBox.autocomplete(boxOpts);
    else
      this.findBox
        .on('tokenfield:removedtoken', function (e) {
          self.requestSent = self.onRemoved && self.onRemoved(e.attrs.value);
        })
        .tokenfield({ autocomplete: boxOpts });

    a$.pass(this, jT.AutocompleteWidget, "init", manager);
  },

  resetValue: function(val) {
    this.findBox.val(val)[this.tokenMode ? 'tokenfield' : 'autocomplete']("enable");
    this.requestSent = false;
  },
  
  onFound: function (list) {
    this.reportCallback && this.reportCallback(list);
    this.requestSent = false;
  }
};
/** jToxKit - chem-informatics multi-tool-kit.
  * A very simple, template rendering Item Widget. Suitable for
  * both ListWidget and TagWidgets
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2016, IDEAConsult Ltd. All rights reserved.
  */

jT.SimpleItemWidget = function (settings) {
  a$.extend(true, this, a$.common(settings, this));
  this.target = $(settings.target);
};

jT.SimpleItemWidget.prototype = {
  template: null,
  classes: null,
  
  renderItem: function (info) {
    return jT.ui.getTemplate(template, info).addClass(this.classes);
  }
};
/** jToxKit - chem-informatics multi-tool-kit.
  * An expansion builder for existing Accordion widget
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2017, IDEAConsult Ltd. All rights reserved.
  */

jT.AccordionExpansion = function (settings) {
  a$.extend(true, this, a$.common(settings, this));

  this.target = $(settings.target);
  this.header = null;
  this.id = settings.id;
  
  // We're resetting the target, so the rest of skills get a true one.
  if (this.automatic)
    settings.target = this.makeExpansion();
};

jT.AccordionExpansion.prototype = {
  automatic: true,
  title: null,
  classes: null,
  expansionTemplate: null,
  before: null,
  
  renderExpansion: function (info) {
    return jT.ui.getTemplate(this.expansionTemplate, info).addClass(this.classes);
  },
  
  makeExpansion: function (before, info) {
    // Check if we've already made the expansion
    if (!!this.header)
      return; 
      
    if (!info)
      info = this;
    if (!before)
      before = this.before;
      
    var el$ = this.renderExpansion(info);

    this.accordion = this.target;
    
    if (!before)
      this.accordion.append(el$);
    else if (typeof before === "number")
      this.accordion.children().eq(before).before(el$);
    else if (typeof before === "string")
      $(before, this.accordion[0]).before(el$);
    else
      $(before).before(el$);
   
    this.refresh();
    this.header = $("#" + this.id + "_header");
		return this.target = $("#" + this.id); // ATTENTION: This presumes we've put that ID to the content part!
  },
  
  getHeaderText: function () {
    return this.header.contents().filter(function () { return this.nodeType == 3; })[0];
  },
  
  refresh: function () {
		this.accordion.accordion("refresh");
  }
};
/** jToxKit - chem-informatics multi-tool-kit.
  * A generic slider (or range) widget
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2017, IDEAConsult Ltd. All rights reserved.
  */

jT.SliderWidget = function (settings) {
  a$.extend(true, this, a$.common(settings, this));

  this.target = $(settings.target);

  this.prepareLimits(settings.limits);
  if (this.initial == null)
    this.initial = this.isRange ? [ this.limits[0], this.limits[1] ] : (this.limits[0] + this.limits[1]) / 2;
    
  this.target.val(Array.isArray(this.initial) ? this.initial.join(",") : this.initial);
    
  if (!!this.automatic)
    this.makeSlider();
};

jT.SliderWidget.prototype = {
  __expects: [ "updateHandler" ],
  limits: null,         // The overall range limit.
  units: null,            // The units of the values.
  initial: null,          // The initial value of the sliders.
  title: null,            // The name of the slier.
  width: null,            // The width of the whole slider.
  automatic: true,        // Whether to automatically made the slider in constructor.
  isRange: true,          // Is this a range slider(s) or a single one?
  showScale: true,        // Whether to show the scale
  format: "%s {{units}}", // The format for value output.
  
  prepareLimits: function (limits) {
    this.limits = typeof limits === "string" ? limits.split(",") : limits;
  
    this.limits[0] = parseFloat(this.limits[0]);
    this.limits[1] = parseFloat(this.limits[1]);
        
    this.precision = Math.pow(10, parseInt(Math.min(1, Math.floor(Math.log10(this.limits[1] - this.limits[0] + 1) - 3))));
    if (this.precision < 1 && this.precision > .01) 
      this.precison = .01;
  },
  
  updateSlider: function (value, limits) {
    if (Array.isArray(value))
      value = value.join(",");
      
    if (limits != null) {
      this.prepareLimits(limits);
      this.target.jRange('updateRange', this.limits, value);      
    }
    else
      this.target.jRange('setValue', value);
  },
  
  makeSlider: function () {
    var self = this,
        enabled = this.limits[1] > this.limits[0],
        scale = [
          jT.nicifyNumber(this.limits[0], this.precision), 
          this.title + (enabled || !this.units ? "" : " (" + this.units + ")"), 
          jT.nicifyNumber(this.limits[1], this.precision)
        ],
        updateHandler = self.updateHandler(),
        settings = {
        	from: this.limits[0],
        	to: this.limits[1],
        	step: this.precision,
        	scale: scale,
        	showScale: this.showScale,
        	showLabels: enabled,
        	disable: !enabled,
        	isRange: this.isRange,
        	width: this.width,
        	format: jT.formatString(this.format, this) || ""
      	};
    
    if (this.color != null)
      settings.theme = "theme-" + this.color;
      
    settings.ondragend = function (value) {
      if (typeof value === "string" && self.isRange)
        value = value.split(",");
        
      value = Array.isArray(value) ? value.map(function (v) { return parseFloat(v); }) : parseFloat(value);
      return updateHandler(value);
    };
      
    return this.target.jRange(settings);
  }
};
/** jToxKit - chem-informatics multi-tool-kit.
  * A generic widget for managing current search results
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2020, IDEAConsult Ltd. All rights reserved.
  *
  */

CurrentSearchWidgeting = function (settings) {
  a$.extend(true, this, a$.common(settings, this));
  
  this.target = settings.target;
  this.id = settings.id;
  
  this.manager = null;
  this.facetWidgets = {};
  this.fqName = this.useJson ? "json.filter" : "fq";
};

CurrentSearchWidgeting.prototype = {
  useJson: false,
  renderItem: null,
  
  init: function (manager) {
    a$.pass(this, CurrentSearchWidgeting, "init", manager);
        
    this.manager = manager;
  },
  
  registerWidget: function (widget, pivot) {
    this.facetWidgets[widget.id] = pivot;
  },
  
  afterTranslation: function (data) {
    var self = this,
        links = [],
        q = this.manager.getParameter('q'),
        fq = this.manager.getAllValues(this.fqName);
        
    // add the free text search as a tag
    if (!!q.value && !q.value.match(/^(\*:)?\*$/)) {
        links.push(self.renderItem({ title: q.value, count: "x", onMain: function () {
          q.value = "";
          self.manager.doRequest();
          return false;
        } }).addClass("tag_fixed"));
    }

    // now scan all the filter parameters for set values
    for (var i = 0, l = fq != null ? fq.length : 0; i < l; i++) {
	    var f = fq[i],
          vals = null,
          w;
	    
      for (var wid in self.facetWidgets) {
  	    w = self.manager.getListener(wid);
        vals = w.fqParse(f);
  	    if (!!vals)
  	      break;
  	  }
  	  
  	  if (vals == null) continue;
  	    
  	  if (!Array.isArray(vals))
  	    vals = [ vals ];
  	        
      for (var j = 0, fvl = vals.length; j < fvl; ++j) {
        var v = vals[j], el, 
            info = (typeof w.prepareTag === "function") ? 
              w.prepareTag(v) : 
              {  title: v,  count: "x",  color: w.color, onMain: w.unclickHandler(v) };
        
    		links.push(el = self.renderItem(info).addClass("tag_selected " + (!!info.onAux ? "tag_open" : "tag_fixed")));

    		if (fvl > 1)
    		  el.addClass("tag_combined");
      }
      
      if (fvl > 1)
		    el.addClass("tag_last");
    }
    
    if (links.length) {
      links.push(self.renderItem({ title: "Clear", onMain: function () {
        q.value = "";
        for (var wid in self.facetWidgets)
    	    self.manager.getListener(wid).clearValues();
    	    
        self.manager.doRequest();
        return false;
      }}).addClass('tag_selected tag_clear tag_fixed'));
      
      this.target.empty().addClass('tags').append(links);
    }
    else
      this.target.removeClass('tags').html('<li>No filters selected!</li>');
  }

};

jT.CurrentSearchWidget = a$(CurrentSearchWidgeting);
/** jToxKit - chem-informatics multi-tool-kit.
  * A very simple, widget add-on for wiring the ability to change
  * certain property of the agent, based on a provided UI element.
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2016-2017, IDEAConsult Ltd. All rights reserved.
  */

jT.Switching = function (settings) {
  a$.extend(true, this, a$.common(settings, jT.Switching.prototype));
  var self = this,
      target$ = $(self.switchSelector, $(settings.target)[0]),
      initial = _.get(self, self.switchField);

  // Initialize the switcher according to the field.
  if (typeof initial === 'boolean')
    target$[0].checked = initial;
  else
    target$.val(initial);
        
  // Now, install the handler to change the field with the UI element.
  target$.on('change', function (e) {
    var val = $(this).val();
    
    a$.path(self, self.switchField, typeof initial === 'boolean' ? this.checked || val === 'on' : val);
    a$.act(self, self.onSwitching, e);
    e.stopPropagation();
  });
};

jT.Switching.prototype = {
  switchSelector: ".switcher",  // A CSS selector to find the switching element.
  switchField: null,            // The field to be modified.
  onSwitching: null             // The function to be invoked, on change.
};
/** jToxKit - chem-informatics multi-tool-kit.
  * A very simple, widget add-on for wiring the ability to change
  * certain property of the agent, based on a provided UI element.
  *
  * Author: Ivan (Jonan) Georgiev
  * Copyright © 2016-2017, IDEAConsult Ltd. All rights reserved.
  */

jT.Running = function (settings) {
  a$.extend(true, this, a$.common(settings, jT.Running.prototype));
  var self = this,
      target$ = $(self.runSelector, $(settings.target)[0]),
      runTarget = self.runTarget || self;

  // Now, install the handler to change the field with the UI element.
  target$.on('click', function (e) {
    a$.act(runTarget, self.runMethod, this, e);
    e.stopPropagation();
  });
};

jT.Running.prototype = {
  runSelector: ".switcher",   // A CSS selector to find the switching element.
  runMethod: null,            // The method to be invoked on the given target or on self.
  runTarget: null,            // The target to invoke the method to - this will be used if null.
};
/** jToxKit - chem-informatics multi-tool-kit.
 * Wrapper of table-relevant tools. To be assigned to specific prototype functions
 *
 * Author: Ivan (Jonan) Georgiev
 * Copyright © 2020, IDEAConsult Ltd. All rights reserved.
 */

jT.tables = {
	updateControls: function (qStart, qSize) {
		var pane = $('.jtox-controls', this.rootElement);
		if (!this.settings.showControls) {
			pane.hide();
			return;
		}

		if (qStart == null)
			qStart = this.settings.pageStart;
		if (qSize == null)			
			qSize = this.settings.pageSize;

		jT.ui.updateTree(pane, {
			"pagesize": qSize,
			"pagestart": qSize > 0 ? qStart + 1 : 0,
			"pageend": qStart + qSize
		});

		var nextBut = $('.jtox-handler[data-handler=nextPage]', pane);
		if (this.entriesCount == null || qStart + qSize < this.entriesCount)
			$(nextBut).addClass('paginate_enabled_next').removeClass('paginate_disabled_next');
		else
			$(nextBut).addClass('paginate_disabled_next').removeClass('paginate_enabled_next');

		var prevBut = $('.jtox-handler[data-handler=prevPage]', pane);
		if (qStart > 0)
			$(prevBut).addClass('paginate_enabled_previous').removeClass('paginate_disabled_previous');
		else
			$(prevBut).addClass('paginate_disabled_previous').removeClass('paginate_enabled_previous');
	},

	modifyColDef: function (kit, col, category, group) {
		if (col.title === undefined || col.title == null)
			return null;

		var name = col.title.toLowerCase();

		// helper function for retrieving col definition, if exists. Returns empty object, if no.
		var getColDef = function (cat) {
			var catCol = kit.settings.columns[cat];
			if (catCol != null) {
				if (!!group) {
					catCol = catCol[group];
					if (catCol != null) {
						// Allow visible to be set on the whole category
						if (catCol.visible != null) {
							catCol[name] = catCol[name] || {};
							catCol[name].visible = !!catCol[name].visible || !!catCol.visible;
						}
						catCol = catCol[name];
					}
				} else {
					catCol = catCol[name];
				}
			}

			if (catCol == null)
				catCol = {};
			return catCol;
		};
		// now form the default column, if existing and the category-specific one...
		// extract column redefinitions and merge them all.
		col = $.extend(col, (!!group ? getColDef('_') : {}), getColDef(category));
		return col.visible == null || col.visible ? col : null;
	},

	sortColDefs: function (colDefs) {
		for (var i = 0, l = colDefs.length; i < l; ++i)
			colDefs[i].naturalOrder = i;
		colDefs.sort(function (a, b) {
			var res = (a.order || 0) - (b.order || 0);
			if (res == 0) // i.e. they are equal
				res = a.naturalOrder - b.naturalOrder;
			return res;
		});
	},

	processColumns: function (kit, category) {
		var colDefs = [];
		var catList = kit.settings.columns[category];
		for (var name in catList) {
			var col = this.modifyColDef(kit, catList[name], category);
			if (col != null)
				colDefs.push(col);
		}

		this.sortColDefs(colDefs);
		return colDefs;
	},

	renderMulti: function (data, full, render) {
		// Make a property getter when passed a string.
		if (typeof render === 'string')
			render = _.property(render);
		if (data.length < 2)
			return '<div>' + render(data[0], full) + '</div>';
		else
			return '<table>' + _.map(data, function (entry, idx) {
					return '<tr class="' + (idx % 2 == 0 ? 'even' : 'odd') + '"><td>' + render(entry, full, idx) + '</td></tr>';
				})
				.join('') + 
				'</table>';
	},

	getTable: function (el) {
		return $(el).closest('table.dataTable').DataTable();
	},

	getRowData: function (el) {
		var table = this.getTable(el),
			row = $(el).closest('tr')[0];
		return table && table.row(row).data();
	},

	getCellData: function (el) {
		var table = this.getTable(el),
			cell = $(el).closest('td')[0];
		return table && table.cell(cell).data();
	},

	putTable: function (kit, root, config, settings) {
		var onRow = kit.settings.onRow;
		if (onRow === undefined && settings != null)
			onRow = settings.onRow;

		var opts = $.extend({
			"paging": false,
			"processing": true,
			"lengthChange": false,
			"autoWidth": false,
			"dom": kit.settings.dom || "rt<Fip>",
			"language": kit.settings.oLanguage,
			"serverSide": false,
			"createdRow": function (nRow, aData, iDataIndex) {
				// call the provided onRow handler, if any
				if (typeof onRow == 'function') {
					var res = jT.fireCallback(onRow, kit, nRow, aData, iDataIndex);
					if (res === false)
						return;
				}

				// equalize multi-rows, if there are any
				jT.tables.equalizeHeights.apply(window, $('td.jtox-multi table tbody', nRow).toArray());

				// handle a selection click.. if any
				jT.ui.installHandlers(kit, nRow, jT.tables.commonHandlers);
			}
		}, settings);

		if (opts.columns == null)
			opts.columns = jT.tables.processColumns(kit, config);
		if (opts.language == null)
			delete opts.language;

		var table = $(root).dataTable(opts);
		$(table).DataTable().columns.adjust();
		return table;
	},

	insertRenderer: function (colDef, render, opts) {
		opts = opts || {};
		var oldRender = colDef.render,
			newRender = !oldRender ? render : function (data, type, full) {
				var oldContent = oldRender(data, type, full),
					newContent = render(data, type, full),
					separator = opts.separator || '';

				// In case we're given an array of renders, we'll receive an array of values.
				if (Array.isArray(newContent))
					newContent = newContent.join(separator);

				return (opts.position === 'before') 
					? newContent + separator + oldContent 
					: oldContent + separator + newContent;
			};

		if (Array.isArray(render))
			render = _.over(render);
		if (opts.inplace)
			colDef.render = newRender;
		else
			colDef = $.extend({}, colDef, { render: newRender });
		return colDef;
	},

	getDetailsRenderer: function (subject, handler) {
		var html = '<i class="jtox-details-open fa fa-folder jtox-handler" data-handler="' + (handler || 'toggleDetails') + 
			'" title="Press to open/close detailed info for this ' + subject + '"></i>';
		return function (data, type)  { return type === 'display' ? html : data; }
	},

	getSelectionRenderer: function (subject, handler) {
		return function (data, type, full) {
			return type !== 'display' 
				? data 
				: '<input type="checkbox" value="' + data + '" class="jtox-selection jtox-handler" data-handler="' + (handler || 'toggleSelection') + 
				'" title="Add this ' + (subject || 'entry') + ' to the selection"' + '/>';
		}
	},

	equalizeHeights: function () {
		var tabs = [];
		for (var i = 0; i < arguments.length; ++i)
			tabs[i] = arguments[i].firstElementChild;

		for (;;) {
			var height = 0;
			for (i = 0; i < tabs.length; ++i) {
				if (tabs[i] == null)
					continue;

				if (!$(tabs[i]).hasClass('lock-height') && tabs[i].style.height != '')
					tabs[i].style.height = "auto";

				if (tabs[i].offsetHeight > height)
					height = tabs[i].offsetHeight;
			}

			if (height == 0)
				break;

			for (i = 0; i < tabs.length; ++i) {
				if (tabs[i] != null) {
					$(tabs[i]).height(height);
					tabs[i] = tabs[i].nextElementSibling;
				}
			}
		}
	},

	// Extract the table's contents (i.e. HTML), and glue them into a single table,
	// optionally transposing it.
	extractTable: function (tables, transpose) {
		var colsCnt = 0,
			mergedTable = $('<table>'),
			mergedRows = null;

		// go through all provided tables and extract and merge the cell contents.
		$(tables).map(function (i, root) {
			var newRows = $(root).children().children();

			if (mergedRows == null)
				mergedRows = newRows.clone().appendTo(mergedTable);
			else 
				newRows.each(function (idx, row) {
					$(row).children().clone().appendTo(mergedRows[idx]);
					colsCnt = Math.max(colsCnt, mergedRows[idx].children.length);
				});
		});


		// Clear the table from non-important stuff.
		$('.fa.jtox-handler,.ui-icon,.jtox-hidden', mergedTable).remove();
		$('td,th', mergedTable).css('width', 'auto').css('height', 'auto');
		if (transpose === true) {
			if (colsCnt == 0) // i.e. - we have one table...
				mergedRows.each(function (i, r) { colsCnt = Math.max(colsCnt, r.children.length); });

			var resRows = _.times(colsCnt, function (i) { return document.createElement('tr'); });
			mergedRows.each(function (_i, row) {
				$(row).children().each(function (i, cell) {
					var c$ = $(cell),
						cRowSpan = c$.prop('rowspan'),
						cColSpan = c$.prop('colspan');

					c$.appendTo(resRows[i]);
					if (cRowSpan > 1)
						c$.attr('colspan', cRowSpan);
					if (cColSpan > 1)
						c$.attr('rowspan', cColSpan);
				});
			});

			mergedTable.empty().append(resRows);
		}

		return mergedTable;
	},

	commonHandlers: {
		nextPage: function () {
			if (this.entriesCount == null || this.pageStart + this.pageSize < this.entriesCount)
				this.queryEntries(this.pageStart + this.pageSize);
		},
	
		prevPage: function () {
			if (this.pageStart > 0)
				this.queryEntries(this.pageStart - this.pageSize);
		},
		toggleDetails: function (event) {
			var el$ = $(event.target),
				row = el$.closest('tr')[0],
				cell = el$.closest('td')[0];

			el$.toggleClass('fa-folder fa-folder-open jtox-openned');
	
			if (el$.hasClass('jtox-openned')) {
				var detRow = document.createElement('tr'),
					detCell = document.createElement('td');
				detRow.appendChild(detCell);
				$(detCell).addClass('jtox-details');
	
				detCell.setAttribute('colspan', $(row).children().length - 1);
				row.parentNode.insertBefore(detRow, row.nextElementSibling);
	
				cell.setAttribute('rowspan', '2');
	
				return jT.fireCallback(this.settings.onDetails, this, detCell, jT.tables.getRowData(row), el$[0]);
			} else {
				cell.removeAttribute('rowspan');
				$($(row).next()).remove();
				return null;
			}
		},
	}
};
/** jToxKit - chem-informatics multi-tool-kit.
 * Wrapper of common Ambit communication tools.
 *
 * Author: Ivan (Jonan) Georgiev
 * Copyright © 2020, IDEAConsult Ltd. All rights reserved.
 */

jT.ambit = {
	processEntry: function (entry, features, fnValue) {
		if (!fnValue)
			fnValue = defaultSettings.fnAccumulate;

		for (var fid in entry.values) {
			var feature = features[fid];
			if (!feature)
				continue;
			var newVal = entry.values[fid];

			// if applicable - location the feature value to a specific location whithin the entry
			if (!!feature.accumulate && !!newVal && !!feature.data) {
				var fn = typeof feature.accumulate == 'function' ? feature.accumulate : fnValue;
				var accArr = feature.data;
				if (!$.isArray(accArr))
					accArr = [accArr];

				for (var v = 0; v < accArr.length; ++v)
					_.set(entry, accArr[v], jT.fireCallback(fn, this, fid, /* oldVal */ _.get(entry, accArr[v]), newVal, features));
			}
		}

		return entry;
	},

	extractFeatures: function (entry, features, callback) {
		var data = [];
		for (var fId in features) {
			var feat = $.extend({}, features[fId]);
			feat.value = entry.values[fId];
			if (!!feat.title) {
				if (jT.fireCallback(callback, null, feat, fId, data.length) !== false) {
					if (!feat.value)
						feat.value = '-';
					data.push(feat);
				}
			}
		};

		return data;
	},

	parseFeatureId: function (featureId) {
		var parse = featureId.match(/(https?\:\/\/.*)\/property\/([^\/]+)\/([^\/]+)\/(.+)/);
		if (parse == null)
			return null;
		else
			return {
				baseUri: parse[1],
				topcategory: parse[2].replace("+", " "),
				category: parse[3].replace("+", " "),
				suffix: parse[4]
			};
	},

	buildFeatureId: function (parsedFeature, suffix) {
		return parsedFeature.baseUri + '/property/' + 
			parsedFeature.topcategory.replace(' ', '+') + '/' + 
			parsedFeature.category.replace(' ', '+') + '/' +
			parsedFeature.suffix;
	},

	diagramUri: function (uri) {
		return !!uri && (typeof uri == 'string') ? uri.replace(/(.+)(\/conformer.*)/, "$1") + "?media=image/png" : '';
	},

	enumSameAs: function (fid, features, callback) {
		// starting from the feature itself move to 'sameAs'-referred features, until sameAs is missing or points to itself
		// This, final feature should be considered "main" and title and others taken from it.
		var feature = features[fid];
		var base = fid.replace(/(http.+\/feature\/).*/g, "$1");
		var retId = fid;

		for (;;) {
			jT.fireCallback(callback, null, feature, retId);
			if (feature.sameAs == null || feature.sameAs == fid || fid == base + feature.sameAs)
				break;
			if (features[feature.sameAs] !== undefined)
				retId = feature.sameAs;
			else {
				if (features[base + feature.sameAs] !== undefined)
					retId = base + feature.sameAs;
				else
					break;
			}

			feature = features[retId];
		}

		return retId;
	},

	processFeatures: function (features, bases) {
		if (bases == null)
			bases = jT.ambit.baseFeatures;
		features = $.extend(features, bases);

		for (var fid in features) {
			var theFeat = features[fid];
			if (!theFeat.URI)
				theFeat.URI = fid;
			this.enumSameAs(fid, features, function (feature, id) {
				var sameAs = feature.sameAs;
				feature = $.extend(true, feature, theFeat);
				theFeat = $.extend(true, theFeat, feature);
				feature.sameAs = sameAs;
			});
		}

		return features;
	},

	processDataset: function (dataset, features, fnValue, startIdx) {
		if (!features) {
			this.processFeatures(dataset.feature);
			features = dataset.feature;
		}

		if (!fnValue)
			fnValue = defaultSettings.fnAccumulate;

		if (!startIdx)
			startIdx = 0;

		for (var i = 0, dl = dataset.dataEntry.length; i < dl; ++i) {
			this.processEntry(dataset.dataEntry[i], features, fnValue);
			dataset.dataEntry[i].number = i + 1 + startIdx;
			dataset.dataEntry[i].index = i;
		}

		return dataset;
	},

	getDatasetValue: function (fid, old, value) {
		return _.compact(_.union(old, value != null ? value.trim().toLowerCase().split("|") : [value]));
	},

	getDiagramUri: function (URI) {
		return !!URI && (typeof URI == 'string') ? URI.replace(/(.+)(\/conformer.*)/, "$1") + "?media=image/png" : '';
	},
	
	/* Grab the paging information from the given URL and place it into the settings of passed
	kit, as <kit>.settings.pageStart and <kit>.settings.pageSize. Pay attention that it is 'pageStart'
	and not 'pageNo'.
	*/
	grabPaging: function (kit, url) {
		var urlObj = jT.parseURL(url);

		if (urlObj.params['pagesize'] !== undefined) {
			var sz = parseInt(urlObj.params['pagesize']);
			if (sz > 0)
				kit.settings.pageSize = kit.pageSize = sz;
			url = jT.removeParameter(url, 'pagesize');
		}

		if (urlObj.params['page'] !== undefined) {
			var beg = parseInt(urlObj.params['page']);
			if (beg >= 0)
				kit.settings.pageStart = kit.pageStart = beg * kit.settings.pageSize;
			url = jT.removeParameter(url, 'page');
		}

		return url;
	},

	// Makes a server call for provided service, with settings form the given kit and calls 'callback' at the end - always.
	call: function (kit, service, opts, callback) {
		// some parameter deals in the begining.
		if (typeof opts === 'function') {
			callback = opts;
			opts = undefined;
		}

		var settings = $.extend(true, {}, kit.settings.ajaxSettings, opts ),
			accType = settings.plainText ? "text/plain" : (settings.jsonp ? "application/x-javascript" : "application/json");

		if (!settings.data) {
			if (settings.jsonp)
				settings.data = { media: accType };
			if (!settings.method)
				settings.method = 'GET';
		} else if (!settings.method)
			settings.method = 'POST';

		if (!settings.dataType)
			settings.dataType = settings.plainText ? "text" : (settings.jsonp ? 'jsonp' : 'json');
		if (!settings.type)
			settings.type = settings.method;

		// on some queries, like tasks, we DO have baseUrl at the beginning
		if (service.indexOf("http") != 0)
			service = kit.settings.baseUrl + service;

		var myId = self.callId++;
		settings = $.extend(settings, {
			url: service,
			headers: { Accept: accType },
			crossDomain: settings.crossDomain || settings.jsonp,
			timeout: parseInt(settings.timeout),
			jsonp: settings.jsonp ? 'callback' : false,
			error: function (jhr, status, error) {
				jT.fireCallback(settings.onError, kit, service, status, jhr, myId);
				jT.fireCallback(callback, kit, null, jhr);
			},
			success: function (data, status, jhr) {
				jT.fireCallback(settings.onSuccess, kit, service, status, jhr, myId);
				jT.fireCallback(callback, kit, data, jhr);
			}
		})

		jT.fireCallback(settings.onConnect, kit, settings, myId);

		// now make the actual call
		$.ajax(settings);
	},

	taskPoller: function(kit, callback, delay, timeout) {
		var taskStart = null,
			handler = null;

		if (timeout == null)
			timeout = 5 * 1000;
		if (delay == null)
			delay = 250;

		handler = function (task, jhr) {
			if (task == null || task.task == null || task.task.length < 1) {
				callback(task, jhr);
				return;
			}
			task = task.task[0];
			// i.e. - we're ready or we're in trouble.
			if (task.completed > -1 || !!task.error) {
				callback(task, jhr);
				return;
			}
			// first round				
			else if (taskStart == null)
				taskStart = Date.now();
			// timedout
			else if (Date.now() - taskStart > timeout) {
				callback(task, jhr);
				return;
			}
			// time for another call
			setTimeout(function() { 
				jT.ambit.call(kit, task.result, { method: 'GET' }, handler);
			},delay);
		};

		return handler;
	},

	/* define the standard features-synonymes, working with 'sameAs' property. Beside the title we define the 'data' property
	as well which is used in processEntry() to location value(s) from given (synonym) properties into specific property of the compound entry itself.
	'data' can be an array, which results in adding value to several places.
	*/
	baseFeatures: {
		"http://www.opentox.org/api/1.1#REACHRegistrationDate" : { title: "REACH Date", data: "compound.reachdate", accumulate: true, basic: true },
		"http://www.opentox.org/api/1.1#CASRN" : { title: "CAS", data: "compound.cas", accumulate: true, basic: true, primary: true },
		"http://www.opentox.org/api/1.1#ChemicalName" : { title: "Name", data: "compound.name", accumulate: true, basic: true },
		"http://www.opentox.org/api/1.1#TradeName" : { title: "Trade Name", data: "compound.tradename", accumulate: true, basic: true },
		"http://www.opentox.org/api/1.1#IUPACName": { title: "IUPAC Name", data: ["compound.name", "compound.iupac"], accumulate: true, basic: true },
		"http://www.opentox.org/api/1.1#EINECS": { title: "EINECS", data: "compound.einecs", accumulate: true, basic: true, primary: true },
		"http://www.opentox.org/api/1.1#InChI": { title: "InChI", data: "compound.inchi", shorten: true, accumulate: true, basic: true },
		"http://www.opentox.org/api/1.1#InChI_std": { title: "InChI", data: "compound.inchi", shorten: true, accumulate: true, sameAs: "http://www.opentox.org/api/1.1#InChI", basic: true },
		"http://www.opentox.org/api/1.1#InChIKey": { title: "InChI Key", data: "compound.inchikey", accumulate: true, basic: true },
		"http://www.opentox.org/api/1.1#InChIKey_std": { title: "InChI Key", data: "compound.inchikey", accumulate: true, sameAs: "http://www.opentox.org/api/1.1#InChIKey", basic: true },
		"http://www.opentox.org/api/1.1#InChI_AuxInfo": { title: "InChI Aux", data: "compound.inchiaux", accumulate: true, basic: true },
		"http://www.opentox.org/api/1.1#InChI_AuxInfo_std": { title: "InChI Aux", data: "compound.inchiaux", accumulate: true, sameAs: "http://www.opentox.org/api/1.1#InChI_AuxInfo", basic: true},
		"http://www.opentox.org/api/1.1#IUCLID5_UUID": { title: "IUCLID5 UUID", data: "compound.i5uuid", shorten: true, accumulate: true, basic: true, primary: true },
		"http://www.opentox.org/api/1.1#SMILES": { title: "SMILES", data: "compound.smiles", shorten: true, accumulate: true, basic: true },
		"http://www.opentox.org/api/dblinks#CMS": { title: "CMS", accumulate: true, basic: true },
		"http://www.opentox.org/api/dblinks#ChEBI": { title: "ChEBI", accumulate: true, basic: true },
		"http://www.opentox.org/api/dblinks#Pubchem": { title: "PubChem", accumulate: true, basic: true },
		"http://www.opentox.org/api/dblinks#ChemSpider": { title: "ChemSpider", accumulate: true, basic: true },
		"http://www.opentox.org/api/dblinks#ChEMBL": { title: "ChEMBL", accumulate: true, basic: true },
		"http://www.opentox.org/api/dblinks#ToxbankWiki": { title: "Toxbank Wiki", accumulate: true, basic: true },
		"http://www.opentox.org/api/1.1#Diagram": {
			title: "Diagram", search: false, visibility: "main", primary: true, data: "compound.URI", 
			column: { className: "paddingless", width: "125px" },
			render: function (data, type, full) {
				dUri = jT.ambit.getDiagramUri(data);
				return (type != "display") 
					? dUri 
					: '<div class="jtox-diagram borderless"><i class="icon fa fa-search-plus jtox-handler" data-handler="alignTables" data-handler-delay="50"></i>' +
						'<a target="_blank" href="' +  data + '"><img src="' + dUri + '" class="jtox-smalldiagram"/></a></div>';
			}
		},
		'#IdRow': {
			used: true, basic: true, data: "number",
			column: { className: "center" },
			render: function (data, type, full) { 
				return (type != "display") ? data : "&nbsp;-&nbsp;" + data + "&nbsp;-&nbsp;"; 
			}
		},
		"#DetailedInfoRow": {
			title: "InfoRow", search: false, data: "compound.URI", basic: true, primary: true, visibility: "none",
			column: { className: "jtox-hidden jtox-ds-details paddingless", width: "0px" },
			render: function (data, type, full) { return ''; }
		}
	},
	formatters: {
		extIdentifiers: function (data) {
			var html = '';
			for (var i = 0; i < data.length; ++i) {
				if (i > 0)
					html += '<br/>';
				var id = data[i].id;
				try {
					if (id.startsWith("http")) id = "<a href='" + id + "' target=_blank class='qxternal'>" + id + "</a>";
				} catch (err) {}
	
				html += data[i].type + '&nbsp;=&nbsp;' + id;
			}
			return html;
		},
		formatDate: function (timestamp) {
			var d = new Date(timestamp),
				day = d.getDate(),
				month = d.getMonth() + 1;

			return ((day < 10) ? '0' : '') + day + '.' + ((month < 10) ? '0' : '') + month + '.' + d.getFullYear();
		},
		formatConcentration: function (data) {
			var val = data.value;
			if (val == null) {
				val = data.lowerValue;
				if (data.upperValue != null)
					val = val + '-' + data.upperValue;
			}

			return jT.valueAndUnits(val == null ? '?' : val, data.unit || '%&nbsp;(w/w)');
		}
	}
};

})(jToxKit, asSys, jQuery);
